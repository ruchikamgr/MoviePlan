import { GlobalConstants } from './global-constants';

describe('GlobalConstants', () => {
  it('should create an instance', () => {
    expect(new GlobalConstants()).toBeTruthy();
  });
});
